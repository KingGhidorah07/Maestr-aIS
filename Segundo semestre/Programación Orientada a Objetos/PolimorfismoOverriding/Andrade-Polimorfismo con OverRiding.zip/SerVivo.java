public class SerVivo {
    protected int tamaño;
    protected float peso;
    protected String genero;
    protected byte edad;

    public String accion() {
        return "Ser vivo haciendo algo";
    }

}

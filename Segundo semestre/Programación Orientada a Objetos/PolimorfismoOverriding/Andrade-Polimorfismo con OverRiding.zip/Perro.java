public class Perro extends SerVivo{
    private String raza;

    @Override
    public String accion() {
        return "Perro ladrando";
    }
}

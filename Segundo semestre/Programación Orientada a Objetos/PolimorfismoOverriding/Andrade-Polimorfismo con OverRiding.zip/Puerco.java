public class Puerco extends SerVivo{
    private float kilos;

    @Override
    public String accion() {
        return "Puerco gruñendo";
    }
}

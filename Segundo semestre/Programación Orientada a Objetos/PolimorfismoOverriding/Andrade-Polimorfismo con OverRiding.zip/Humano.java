public class Humano extends SerVivo{
    private String nacionalidad;

    @Override
    public String accion() {
        return "Humano caminando";
    }
}

package hilosRunnable;

public class HiloHolaMundo implements Runnable {

    @Override
    public void run() {
        System.out.println("Hola mundo desde un hilo runnable"+Thread.currentThread().getName());
    }
}

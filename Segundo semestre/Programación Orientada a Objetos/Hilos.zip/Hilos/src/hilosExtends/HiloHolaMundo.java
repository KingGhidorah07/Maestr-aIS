package hilosExtends;

public class HiloHolaMundo extends Thread {
    @Override
    public void run() {
        System.out.println("Hola mundo desde un hilo con extends"+super.getName());
    }
}


import hilosRunnable.HiloHolaMundo;
public class Main {
    public static void main(String[] args) throws InterruptedException {
        HiloHolaMundo hilo1 = new HiloHolaMundo();
        HiloHolaMundo hilo2 = new HiloHolaMundo();
        HiloHolaMundo hilo3 = new HiloHolaMundo();
        HiloHolaMundo hilo4 = new HiloHolaMundo();
        HiloHolaMundo hilo5 = new HiloHolaMundo();

        HiloHolaMundo hilo1Runnable = new HiloHolaMundo();
        Thread t1 = new Thread(hilo1Runnable);
        Thread t2= new Thread(hilo1Runnable," Ivan");

        t1.start();
        t2.start();
        
        while (t1.isAlive() || t2.isAlive());
        System.out.println("ya termine");


    }
}

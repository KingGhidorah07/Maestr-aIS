public abstract class Constantes {

    public static final double PI = 3.14159265358979323846;
    public static final int LADOS_CUADRADO = 4;
    public static final int LADOS_TRIANGULO = 3;
    public static final int LADOS_PENTAGONO = 5;
    public static final int ANGULOS_CIRCULO = 360;

}

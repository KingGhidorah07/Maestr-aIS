interface Figura {

    public abstract double getArea();
    public abstract double getPerimetro();

}

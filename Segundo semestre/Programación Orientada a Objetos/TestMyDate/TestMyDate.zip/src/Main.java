//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        MyDate fecha = new MyDate((byte) 06, (byte) 10, 2024);
        System.out.println(fecha.toString());  // Salida: 09/07/2024
    }
}
